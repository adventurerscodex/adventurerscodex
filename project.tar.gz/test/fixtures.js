var AppearanceFixture = {
    "height":"5'1\"",
    "weight":"123",
    "hairColor":"Brown",
    "eyeColor":"Blue",
    "skinColor":"Red"
};

var AbilitiesFixture = {
	'str': 12,
	'dex': 13,
	'con': 14,
	'int': 16,
	'wis': 15,
	'cha': 18
};

var FeatsProfFixture = {
    'feats': 'tough',
    'proficiencies': 'simple weapons',
    'specialAbilities': 'darkvision'
};

var SpellStatsFixture = {
    "spellcastingAbility":"INT",
    "spellSaveDc":3,
    "spellAttackBonus":4,
};

var ArmorFixture = {
    armorName: 'shield of stuff'
};

var CampaignFixture = {
    campaignName: 'Hoard of the Dragon Queen',
    dmName: 'Brian Schrader',
    campaignSummary: 'Hoard of the Dragon Queen by Brian Schrader'
};
