CharacterManager.activeCharacter = function() {
    return {
        key: function() { return '1234'; }
    };
};
