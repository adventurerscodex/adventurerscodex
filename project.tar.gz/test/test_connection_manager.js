"use strict";

describe('Connection Manager View Model', function() {
	describe('Join Room', function() {
		it('should join the given room and set the connection flag', function() {
		});
	});

	describe('Create Room', function() {
		it('should create the given room and set the connection flag', function() {
		});
	});
});

