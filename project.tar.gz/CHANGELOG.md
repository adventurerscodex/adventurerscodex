version 0.0.2 (1/9/2016)

* drag and drop profile pictures with option gravatar config
* improved character sheet layout
* added character sheet wizard
* added prepared spells checkbox to spell module
* added a field for diety in profile module
* dm can now see character hp, ac, name and pic
* added weapon and armor module
* export data now well formatted
* various bug fixes


