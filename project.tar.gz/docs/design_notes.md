# App Design Notes

- Im thinking only browsers that support WebSockets (just throw up a thing that says "you can't use this" otherwise)
- Bootstrap, Knockout, and LocalStorage
